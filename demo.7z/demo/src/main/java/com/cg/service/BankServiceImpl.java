package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.BankDao;
import com.cg.entity.BankCustomer;

@Service
@Transactional
public class BankServiceImpl implements BankService {

	@Autowired
	BankDao bankdao;
	@Override
	public BankCustomer addAccount(BankCustomer bank) {
		
		return bankdao.addAccount(bank);
	}

	@Override
	public BankCustomer showBalance(int accountNo) {
		
		return bankdao.showBalance(accountNo);
	}

	@Override
	public BankCustomer deposit(int accountNo, int amount) {
		
		return bankdao.deposit(accountNo, amount);
	}

	@Override
	public BankCustomer withdraw(int accountNo, int amount) {
		
		return bankdao.withdraw(accountNo, amount);
	}

	@Override
	public BankCustomer fundTransfer(int accountNo, int accountNo2, int amount) {
		
		return bankdao.fundTransfer(accountNo, accountNo2, amount);
	}

}
