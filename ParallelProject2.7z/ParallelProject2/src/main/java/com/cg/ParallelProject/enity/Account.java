package com.cg.ParallelProject.enity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

@Entity
@Table(name="accountprjj")
@Component
public class Account implements Serializable{
	@Id
	
private int accnum;

private String accname;

private long mobilenumber;

private long adharnumber;
private int walbalance;
private int deposit;
private int withdraw;
private int transfer;
public Account() {
	super();
	// TODO Auto-generated constructor stub
}
public Account(int accnum,  String accname,  long mobilenumber,  long adharnumber,
		int walbalance, int deposit, int withdraw, int transfer) {
	super();
	this.accnum = accnum;
	this.accname = accname;
	this.mobilenumber = mobilenumber;
	this.adharnumber = adharnumber;
	this.walbalance = walbalance;
	this.deposit = deposit;
	this.withdraw = withdraw;
	this.transfer = transfer;
}
@Override
public String toString() {
	return "Account [accnum=" + accnum + ", accname=" + accname + ", mobilenumber=" + mobilenumber + ", adharnumber="
			+ adharnumber + ", walbalance=" + walbalance + ", deposit=" + deposit + ", withdraw=" + withdraw
			+ ", transfer=" + transfer + "]";
}
public int getAccnum() {
	return accnum;
}
public void setAccnum(int accnum) {
	this.accnum = accnum;
}
public String getAccname() {
	return accname;
}
public void setAccname(String accname) {
	this.accname = accname;
}
public long getMobilenumber() {
	return mobilenumber;
}
public void setMobilenumber(long mobilenumber) {
	this.mobilenumber = mobilenumber;
}
public long getAdharnumber() {
	return adharnumber;
}
public void setAdharnumber(long adharnumber) {
	this.adharnumber = adharnumber;
}
public int getWalbalance() {
	return walbalance;
}
public void setWalbalance(int walbalance) {
	this.walbalance = walbalance;
}
public int getDeposit() {
	return deposit;
}
public void setDeposit(int deposit) {
	this.deposit = deposit;
}
public int getWithdraw() {
	return withdraw;
}
public void setWithdraw(int withdraw) {
	this.withdraw = withdraw;
}
public int getTransfer() {
	return transfer;
}
public void setTransfer(int transfer) {
	this.transfer = transfer;
}
}