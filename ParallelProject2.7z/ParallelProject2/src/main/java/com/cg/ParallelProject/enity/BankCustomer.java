package com.cg.ParallelProject.enity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

@Entity
@Table(name="accountprjj")
@Component
public class BankCustomer implements Serializable{
	@Id
	
private int accnum;

private String accname;

private long mobilenumber;

private String branch;
private int balance;
private int deposit;
private int withdraw;
private int transfer;

public int getAccnum() {
	return accnum;
}
public void setAccnum(int accnum) {
	this.accnum = accnum;
}
public String getAccname() {
	return accname;
}
public void setAccname(String accname) {
	this.accname = accname;
}
public long getMobilenumber() {
	return mobilenumber;
}
public void setMobilenumber(long mobilenumber) {
	this.mobilenumber = mobilenumber;
}
public String getBranch() {
	return branch;
}
public void setBranch(String branch) {
	this.branch = branch;
}
public int getBalance() {
	return balance;
}
public void setBalance(int balance) {
	this.balance = balance;
}
public int getDeposit() {
	return deposit;
}
public void setDeposit(int deposit) {
	this.deposit = deposit;
}
public int getWithdraw() {
	return withdraw;
}
public void setWithdraw(int withdraw) {
	this.withdraw = withdraw;
}
public int getTransfer() {
	return transfer;
}
public void setTransfer(int transfer) {
	this.transfer = transfer;
}
@Override
public String toString() {
	return "BankCustomer [accnum=" + accnum + ", accname=" + accname + ", mobilenumber=" + mobilenumber + ", branch="
			+ branch + ", balance=" + balance + ", deposit=" + deposit + ", withdraw=" + withdraw + ", transfer="
			+ transfer + "]";
}
public BankCustomer(int accnum, String accname, long mobilenumber, String branch, int balance, int deposit,
		int withdraw, int transfer) {
	super();
	this.accnum = accnum;
	this.accname = accname;
	this.mobilenumber = mobilenumber;
	this.branch = branch;
	this.balance = balance;
	this.deposit = deposit;
	this.withdraw = withdraw;
	this.transfer = transfer;
}
public BankCustomer() {
	super();
	// TODO Auto-generated constructor stub
}

}