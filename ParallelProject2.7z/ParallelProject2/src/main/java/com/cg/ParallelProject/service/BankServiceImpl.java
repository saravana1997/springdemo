package com.cg.ParallelProject.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import com.cg.ParallelProject.dao.BankRepository;
import com.cg.ParallelProject.enity.BankCustomer;

@Service
public class BankServiceImpl implements BankService{
	@Autowired
BankRepository accrepo;
	@Autowired
	BankCustomer bank;
	@Override
	public BankCustomer createAccount(BankCustomer bank) {
		int min=100000000;
		int max=999999999;
		int range=(max-min)+1;
		int accnum=(int)(Math.random()*range)+min;
		bank.setAccnum(accnum);
		return accrepo.save(bank);
	}

	@Override
	public int showbalance(int accnum) {
		
		return accrepo.findById(accnum).get().getBalance();
	}

	@Override
	public int deposit(int accnum, int deposit) {
		bank=accrepo.findById(accnum).get();
		int walbalance=bank.getBalance()+deposit;
		bank.setBalance(walbalance);
		bank.setDeposit(deposit);
		accrepo.save(bank);
		return bank.getDeposit();
	}

	@Override
	public int withdraw(int accnum, int withdraw) {
		bank=accrepo.findById(accnum).get();
		if(bank.getBalance()<withdraw) {
			System.out.println("insufficient funds");
		return 0;
		}
		else {
		 int balance =bank.getBalance()-withdraw;
		 bank.setBalance(balance);
		 bank.setWithdraw(withdraw);
		 accrepo.save(bank);
		 return bank.getWithdraw();
		}
			
	}

	@Override
	public int transfer(int accnum, int transfer) {
		bank=accrepo.findById(accnum).get();
		if(bank.getBalance()<transfer) {
			System.out.println("insufficient funds");
		return 0;
		}
		else {
		 int balance = bank.getBalance()-transfer;
		 bank.setBalance(balance);
		 bank.setTransfer(transfer);
		 accrepo.save(bank);
		 return bank.getTransfer();
		}
	}

	@Override
	public String validateAccnum(int accnum) {
		String str;
		bank=accrepo.findById(accnum).get();
				if(bank!=null) {
					str="account number exists";
			return str;
				}
				else {
					str="account number not exists";
		return str;
				}
	}

}
