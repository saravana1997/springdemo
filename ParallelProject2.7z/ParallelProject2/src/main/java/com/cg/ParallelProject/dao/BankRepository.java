package com.cg.ParallelProject.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.ParallelProject.enity.BankCustomer;
@Repository
public interface BankRepository extends JpaRepository<BankCustomer, Integer>{

}
