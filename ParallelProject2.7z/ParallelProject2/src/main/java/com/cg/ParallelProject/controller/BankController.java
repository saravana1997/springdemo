package com.cg.ParallelProject.controller;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import com.cg.ParallelProject.enity.BankCustomer;
import com.cg.ParallelProject.service.BankService;

@RestController
public class BankController {
	@Autowired
BankService bankservice;
	@Autowired
	BankCustomer bank;
	@PostMapping(value="/createaccount",produces="application/json",consumes= {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<BankCustomer> createAccount(@RequestBody BankCustomer bank) {
		BankCustomer e = bankservice.createAccount(bank);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{accnum}").build(e.getAccnum());

		return ResponseEntity.created(location).build();	
	}
	@GetMapping(value="/showbalance/{accnum}")
	public int show(@PathVariable int accnum) {
		return bankservice.showbalance(accnum);
	}
	@PostMapping(value="/deposit/{accnum}/{amount}")
	public int deposit(@PathVariable int accnum,@PathVariable int amount) {
		return bankservice.deposit(accnum, amount);
		
	}
	@PostMapping(value = "/withdraw/{accnum}/{amount}")
	public int withdraw(@PathVariable int accnum,@PathVariable int amount) {
		System.out.println(accnum+"--"+amount);
		return bankservice.withdraw(accnum, amount);
		}
	@PostMapping(value="/fundtransfer/{accnum}/{amount}")
	public int fundT(@PathVariable int accnum,@PathVariable int amount) {
		return bankservice.transfer(accnum, amount);
	}
}
